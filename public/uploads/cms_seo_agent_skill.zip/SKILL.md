---
name: cms-seo-agent-skill
description: "Bộ kỹ năng toàn diện cho AI Agent tích hợp với hệ thống CMS Blog SEO: Nghiên cứu SERP, Viết bài chuẩn E-E-A-T, UI Elements Library, Internal Linking 2 chiều, Schema JSON-LD, Indexing Push, Quản lý Trang tĩnh (Pages), Menu Navigation & Footer và Quản lý Task tự động."
version: "4.0.0"
author: "CMS Blog SEO Team"
tags: ["seo", "ai-agent", "cms", "content-writing", "schema-markup", "internal-linking", "serp-analysis", "pages-management", "navigation"]
---

# CMS BLOG SEO AGENT SKILL (V4.0)

Bộ Skill này đóng gói toàn bộ quy trình, công cụ API, hướng dẫn viết bài thuần Prompt, quản trị Trang tĩnh (Pages), Menu Điều Hướng & Footer và thư viện UI Elements cho AI Agent tự động hóa 100% nghiệp vụ SEO Content & Website Management.

### 🌐 Thông Số Kết Nối Hệ Thống:
- **Base URL Website**: `http://localhost:5000`
- **Cổng API Endpoint**: `http://localhost:5000/api/agent.php`
- **Host / Server**: `localhost:5000`

---

## 📂 CẤU TRÚC BỘ SKILL (MODULAR ARCHITECTURE)

Bộ kỹ năng được chia nhỏ thành các tài liệu chuyên biệt để AI Agent nạp ngữ cảnh nhanh và chính xác nhất:

| File | Tên tài liệu | Mục đích & Trách nhiệm |
| :--- | :--- | :--- |
| [`AGENT.md`](./AGENT.md) | **Agent Manifest & Verification** | File xác nhận danh tính, kiểm tra quyền và các ràng buộc cốt lõi trước khi chạy. |
| [`01_authentication_and_api.md`](./01_authentication_and_api.md) | **API Reference & Giao thức Kết nối** | Danh mục đầy đủ 24+ API actions, Bearer Auth, Scopes, Rate limit, Idempotency. |
| [`02_workflow_and_task_lifecycle.md`](./02_workflow_and_task_lifecycle.md) | **Vòng đời Nhiệm vụ & Event Pipeline** | Quy trình nhận việc, cập nhật tiến độ, hoàn thành task và kích hoạt Event Hooks. |
| [`03_ai_content_writer_prompt.md`](./03_ai_content_writer_prompt.md) | **Quy Chuẩn Viết Bài Thuần Prompt** | Master Prompt, tiêu chuẩn Google E-E-A-T, Search Intent, cấu trúc PAS/AIDA, chống AI Slop. |
| [`04_ui_elements_library.md`](./04_ui_elements_library.md) | **Thư viện UI Elements Chuẩn HTML/CSS** | 13 nhóm giao diện chuẩn hóa (TOC, Callout, Pros/Cons, Table, FAQ, CTA...). |
| [`05_serp_and_intent_analysis.md`](./05_serp_and_intent_analysis.md) | **Phân tích SERP & Đối thủ Thời Gian Thực** | Công cụ cào dữ liệu Top 10 Google, bóc tách Heading đối thủ, phát hiện Content Gap. |
| [`06_internal_linking_and_seo_schema.md`](./06_internal_linking_and_seo_schema.md) | **Internal Linking 2 Chiều & Schema JSON-LD** | Gợi ý link đi/về, vá Orphan Pages, chèn JSON-LD (FAQPage, HowTo, BlogPosting). |
| [`07_indexing_and_automation.md`](./07_indexing_and_automation.md) | **Tự động hóa Indexing & Giám sát Rank** | Giao thức IndexNow, Ping Sitemap, Event Monitor phát hiện rớt hạng. |
| [`08_examples_and_payloads.md`](./08_examples_and_payloads.md) | **Payload Mẫu & Kịch Bản Gọi API** | Toàn bộ mẫu Request / Response JSON thực chiến cho mọi tình huống. |

---

## 🚀 QUY TRÌNH THỰC THI 8 BƯỚC (QUICK WORKFLOW)

```mermaid
flowchart TD
    A[1. Đọc AGENT.md & Xác thực Token] --> B[2. Lấy Task từ GET http://localhost:5000/api/agent.php?action=tasks]
    B --> C[3. Cào SERP qua action=analyze_serp & Khóa Intent]
    C --> D[4. Nạp Master Prompt từ 03_ai_content_writer_prompt.md]
    D --> E[5. Ghép 2-4 UI Elements từ 04_ui_elements_library.md]
    E --> F[6. Lấy link nội bộ & Build Schema JSON-LD]
    F --> G[7. Gửi bản nháp qua action=create_draft]
    G --> H[8. Báo cáo hoàn thành qua action=complete_task]
```

---

## 🔒 NGUYÊN TẮC BẤT DI BẤT DỊCH (NON-NEGOTIABLE RULES)

1. **Bảo mật**: Chỉ truyền Token qua Header `Authorization: Bearer <TOKEN>`. Nghiêm cấm truyền qua URL query string.
2. **Đồng bộ tiến độ**: Không tự giữ task ngầm trong bộ nhớ cục bộ (Local Context). Mọi công việc phải được ghi nhận và tick hoàn thành trên CMS.
3. **Nội dung thực chiến**: Tuân thủ nghiêm ngặt Master Prompt tại [`03_ai_content_writer_prompt.md`](./03_ai_content_writer_prompt.md) để không tạo ra AI Slop (nội dung rác).
4. **UI Elements**: Chỉ sử dụng đúng các class CSS và thẻ HTML được quy định tại [`04_ui_elements_library.md`](./04_ui_elements_library.md).
